#include<iostream>
using namespace std;
#define MAXSIZE 20
#define WHITE 0
#define BLACK 1
#define GRAY  2
int graph[MAXSIZE][MAXSIZE];

int main(){
cout<<"Enter the number of Vertices : ";
cin>>n;
cout<<"Enter the number of Edges : ";
cin>>m;







return 0;
}
